# VORON M4 Extruder

![Image of M4](http://vorondesign.com/images/voron_m4_bg.jpg)

This is the VORON M4 Extruder. It's a dual geared hobbed filament extruder designed for the Voron family of printers. It features a 4:1 belt driven design to provide torque while being able to be near silent. It borrows the best parts of the various extruders we've released over the past 5 years.

![Voron Logo](http://vorondesign.com/images/voron_design_logo.png)